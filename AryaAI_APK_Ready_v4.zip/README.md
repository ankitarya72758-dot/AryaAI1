# Arya AI v3 — Runway Gen-4.5 Photo → 5-Minute Video

This version upgrades the previous demo into a real API-backed workflow.

### Architecture

Android app → Arya backend → Runway Gen-4.5 → 30 clips → FFmpeg merge → final MP4

### Why a backend is required

The Runway API secret must not be embedded in the Android APK. Keep it on the server.

### Current model choice

Runway Gen-4.5 is the default because the current Runway API supports image-to-video and Gen-4.5 supports 2–10 second generations. The app turns a requested 5-minute video into 30 sequential 10-second clips.

### Cost warning

Runway currently lists Gen-4.5 at 12 credits/second. A 300-second output is therefore about 3,600 credits before retries. For a cheaper build, set `RUNWAY_MODEL=gen4_turbo` on the server and adjust the duration logic if desired.

### Setup

1. Open this Android project in Android Studio.
2. Set up and start the `server` folder as described in `server/README.md`.
3. Put your backend URL in the app's Photo → Video dialog.
4. Select a photo, enter a motion prompt, and tap Generate.

The Android app polls the backend until the final MP4 is ready.
